/* This software was developed at the National Institute of Standards and
 * Technology by employees of the Federal Government in the course of their
 * official duties. Pursuant to title 17 Section 105 of the United States
 * Code this software is not subject to copyright protection and is in the
 * public domain. NIST assumes no responsibility whatsoever for its use by
 * other parties, and makes no guarantees, expressed or implied, about its
 * quality, reliability, or any other characteristic.

 * We would appreciate acknowledgement if the software is used.
 * The SAMATE project website is: http://samate.nist.gov
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>

const char fName[] = "test.file";
const char string[] = "What I want to write";

void handler(int curPid)
{
	fprintf (stdout, "(%d) Start handler...\n",curPid);
	FILE *fp = (FILE *)NULL;
	if ((fp = fopen(fName, "wb")) != (FILE *)NULL)
	{
		fwrite((void *)string, sizeof(char), 20, fp);
		fclose(fp);
	}
	// send the message to the child which should be in fork
	fprintf (stdout, "(%d) Stop handler...\n",curPid);
}

int main(int argc, char *argv[])
{
	pid_t pid = 0;
	// create fork 1
	if (fork())
		return 0;
	
	for (unsigned i=0;i<3;++i) {
		pid = fork();
		if (pid)
		{
			printf ("Run: %d\n",pid);
			handler(pid);
		}
	}
	return 0;
}
